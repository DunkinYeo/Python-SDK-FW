"""Test Slack payload generation without sending."""
import json
import sys
sys.path.insert(0, 'scripts')

from send_slack_notification import load_test_results, extract_device_info, extract_packet_info, build_slack_payload

# Load test results
report = load_test_results()
if not report:
    print("❌ Failed to load test results")
    sys.exit(1)

# Extract information
device_info = extract_device_info(report)
packet_info = extract_packet_info(report)

# Build payload
payload = build_slack_payload(report, device_info, packet_info)

# Pretty print the payload
print("\n" + "="*60)
print("📤 Slack 알림 페이로드 미리보기")
print("="*60 + "\n")
print(json.dumps(payload, indent=2, ensure_ascii=False))
print("\n" + "="*60)
print("✅ 페이로드 생성 성공!")
print("="*60 + "\n")
