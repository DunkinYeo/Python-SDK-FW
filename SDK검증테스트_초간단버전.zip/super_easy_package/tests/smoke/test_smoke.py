import pytest

@pytest.mark.smoke
def test_smoke():
    assert 1 == 1