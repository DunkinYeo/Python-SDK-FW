"""Page Object Model for SDK validation app."""
